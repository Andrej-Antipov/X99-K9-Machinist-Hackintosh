Auto_KLED:

Setup service to switch wired gaming keyboard light. Turning on light on wake and login.

Manual_KLED: 

Switch on or off light on every launch the applet. 
