A theme by InsanelyDeepak.

This theme is created for Clover Bootloader

Credits:
- Umesh Ravani 
- Chrisstian
- CosmosCJ
- BlackOSX 