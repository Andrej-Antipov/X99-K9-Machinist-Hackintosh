This version works ONLY with SIP disabled !

Also the PMDrvr.kext must not be loaded from OpenCore (Сlover) kext folder. 

PMDrvrLdr - before ensure the kext can be load/unload manually

Эта версия работает только с выключенным SIP!

А также не загружайте PMDrvr.kext загрузчиком Clover (OpenCore).

Перед установкой убедитесь что можете загрузить/выгрузить кекст вручную программой PMDrvrLdr